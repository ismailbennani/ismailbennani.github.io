module RealArray = Sundials.RealArray

type time = float
type params = float array
type nvec = float array
type smat = float array array

type rhsfn = params -> time -> nvec -> nvec

type t = {
  nvec : Sundials_cvodes.nvec;
  smat : Sundials_cvodes.sensmat;
  session : Sundials_cvodes.t;
}

let init f params nvec0 smat0 = 
  let ndim = Array.length nvec0 in
  let nvec = Sundials_cvodes.cmake ndim in 
  let cvec = Sundials_cvodes.unvec nvec in
  Array.iteri (fun i v -> cvec.{i} <- v) nvec0;

  let sdim1 = Array.length smat0 in
  let sdim2 = Array.fold_left max 0 (Array.map Array.length smat0) in
  let smat = Sundials_cvodes.smake sdim1 sdim2 in
  Array.iteri (fun i a -> Array.iteri (fun j v -> Sundials_cvodes.sset smat i j v) a) smat0;

  let params = RealArray.of_array params in

  let derivatives params t cvec dvec = 
    let params = RealArray.to_array params in
    let cvec = RealArray.to_array cvec in
    let dvec_arr = f params t cvec in
    Array.iteri (fun i v -> dvec.{i} <- v) dvec_arr
  in

  let session = Sundials_cvodes.initialize derivatives params nvec smat in
  Sundials_cvodes.set_stop_time session 100.;

  { nvec; smat; session; }

let reinit { session; nvec } t nvec0 smat0 =
  let nvec = Sundials_cvodes.cmake (Array.length nvec0) in 
  let cvec = Sundials_cvodes.unvec nvec in
  Array.iteri (fun i v -> cvec.{i} <- v) nvec0;

  let smat = Sundials_cvodes.smake (Array.length smat0) (Array.length smat0.(0)) in
  Array.iteri (fun i a -> Array.iteri (fun j v -> Sundials_cvodes.sset smat i j v) a) smat0;

  Sundials_cvodes.reinitialize session t nvec smat;

  { nvec; smat; session }

let step { nvec; session } horizon =
  Sundials_cvodes.step session horizon nvec

let get_dky { nvec; session } t i =
  Sundials_cvodes.get_dky session nvec t i;
  RealArray.to_array (Sundials_cvodes.unvec nvec)

let arrays_of_sensmat smat =
  Array.map (fun a ->
      let n = Array.length a in
      (* for some reason, the values in realarray are in the wrong order,
          this is a dirty fix for this issue *)
      Array.init n (fun i -> a.(n - i - 1))
  ) (Sundials_cvodes.arrays_of_sensmat smat)

let get_sdky { smat; session } t i =
  Sundials_cvodes.get_sens_dky session smat t i;
  arrays_of_sensmat smat